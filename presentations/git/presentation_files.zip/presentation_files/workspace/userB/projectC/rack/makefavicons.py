import os, sys, argparse, shutil, Image

#params
parser = argparse.ArgumentParser()
parser.add_argument("-s","--sourceImg", type=str, help="location of image")
args = parser.parse_args()

#get all files in source directory
#sourceList = listdir_nohidden(args.sourceDir)
#print(args)

#========================================================
# PROCESS ORGINAL IMAGES
#imgFunctions.tmgProcessImages (sourceList,args.sourceDir,fullDir,False)
#========================================================
print('* Processing Favicons...')
im = Image.open(args.sourceImg)
size = 144,144
im.thumbnail(size,Image.ANTIALIAS)
im.save('apple-touch-icon-144x144-precomposed.png', option='optimize')

size = 114,114
im.thumbnail(size,Image.ANTIALIAS)
im.save('apple-touch-icon-114x114-precomposed.png', option='optimize')

size = 72,72
im.thumbnail(size,Image.ANTIALIAS)
im.save('apple-touch-icon-72x72-precomposed.png', option='optimize')

size = 57,57
im.thumbnail(size,Image.ANTIALIAS)
im.save('apple-touch-icon-57x57-precomposed.png', option='optimize')
im.thumbnail(size,Image.ANTIALIAS)
im.save('apple-touch-icon-precomposed.png', option='optimize')

size = 57,57
im.thumbnail(size,Image.ANTIALIAS)
im.save('apple-touch-icon.png', option='optimize')

size = 16,16
im.thumbnail(size,Image.ANTIALIAS)
im.save('favicon.ico')

print ('*** Processing Complete!')