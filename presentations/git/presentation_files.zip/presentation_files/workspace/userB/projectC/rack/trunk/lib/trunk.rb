#========================================================
# TRUNK GEM
#========================================================
module TRUNK		
	#-- deploys new project framework
	def self.new(name = 'new_project')
		#check for project name
		if name.nil?
			Util.trunkPuts("Trunk needs a name for your project.","error")
			exit!
		end
		
		Util.trunkPuts("Deploying a fresh Trunk project...")
		
		workDir = Dir.pwd #change current working directory to the sites directory
		Dir.chdir(ADDRESS_BOOK::LOCAL["sites"])
		
		#current directory is where we are putting the files
		target = Dir.pwd
		
		#boliler plate directory
		source = ADDRESS_BOOK::LOCAL["boilerplate"]
		
		#copy 
		FileUtils.cp_r source, target
		
		#rename directory
		if File.exists?(target + '/' + name)
			Util.trunkPuts("There is a directory with that name already.","error")
			Util.trunkPuts("Please choose a different name, or rename the \"#{name}\" directory.","error")
			exit!
		end
		FileUtils.mv target+'/~new_project', name
		
		#set project directory
		newProject = target + '/' + name
		Util.trunkPuts("Complete! Trunk project deployed @ -> " + newProject)
		
		#setup git
		Util.trunkPuts("Setting up GIT...")
		
		Dir.chdir(newProject)
		#add local
		Util.runCommand("git init")
		
		#add remote
		Dir.chdir("/Users/tgrux/Dropbox/GIT")
		Util.runCommand("mkdir -p #{name}.git")
		Dir.chdir("/Users/tgrux/Dropbox/GIT/#{name}.git")
		Util.runCommand("git --bare init")
		Dir.chdir("/web/#{name}")
		Util.runCommand("git remote add dropbox file://$HOME/Dropbox/Git/#{name}.git")
		Util.trunkPuts("Git remote dropbox added!")	
		
		#add hook for auto commit to dropbox
		FileUtils.cp_r "git_hooks/post-commit", ".git/hooks/post-commit"
		Util.trunkPuts("Git commit hook added for auto push to dropbox on commit!")	
		Util.runCommand("chmod +x .git/hooks/post-commit")
		
		#add all
		Util.runCommand("git add --all")
		Util.runCommand('git commit -m "initial setup and add" ')
		system('git status')
		
		#setup local vhost file
		FileUtils.mkdir('_vhost')
		Dir.chdir("_vhost")
		vhostFile = File.new("local-#{name}", "w")
		vhostFile.puts("
<VirtualHost *:80>
    ServerName #{name}.10.0.1.3.xip.io
    ServerAlias *.#{name}.10.0.1.3.xip.io
    ServerAlias #{name}.127.0.0.1.xip.io
    ServerAlias *.#{name}.127.0.0.1.xip.io
    
    DocumentRoot /web/#{name}/html/
    
    # debug, info, notice, warn, error, crit, alert, emerg.
    LogLevel debug
</VirtualHost>")
		
		#create vhost sym link
		File.symlink(File.expand_path(vhostFile), "/etc/apache2/sites-enabled/#{name}")
		vhostFile.close
		
		#DONE!
		Dir.chdir(workDir) #put working directory back
		Util.trunkPuts("Trunk project setup complete!")
	end

end


#========================================================
# UTILITIES
# utility methods used in multiple methods in the tristro script
#========================================================
module Util
	def self.copyDirFiles(sourceDir,targetDir)
		if File.exists?(sourceDir)
			FileUtils.mkdir(targetDir) if !File.exist?(targetDir)
			FileUtils.cp Dir[sourceDir+"/*"].collect{|f| File.expand_path(f)}, targetDir
			return true
		end
	end
	def self.runCommand(com)
		command = Thread.new do
		  	system(com) # long-long programm
		end
		command.join # main programm waiting for thread
		puts '*** complete'
	end
	def self.trunkPuts(string,type = nil)
		puts "--	"+string if type.nil?
		puts "!!	"+string if type == "error"
	end
end












# ~ TMG ~